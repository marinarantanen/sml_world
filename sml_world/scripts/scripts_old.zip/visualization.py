#!/usr/bin/env python
# license removed for brevity
"""
Visualization mode of the SML-World.

Created on Feb 23, 2016

@author: U{David Spulak<spulak@kth.se>}
@organization: KTH
"""

import os
import sys
import time
import json

import rospy
from std_msgs.msg import String

import pygame

sys.path.append('RoadModule')
import RoadModule

global screen
global image_center
global blit_bg
global pg_background

def update_state(data):
    car = pygame.image.load('resources/carRedOffset.png')
    
    d = json.loads(data.data)
    print d
    car_small = pygame.transform.smoothscale(car, (26, 7))
    global screen
    global image_center
    blits_bg = []
    for id in d:
        car_small_rot = pygame.transform.rotate(car_small, float(d[id]['yaw']))
        pos = (float(d[id]['x'])*3.18336162988+image_center[0]-car_small_rot.get_rect()[2]/2., -float(d[id]['y'])*3.18336162988+image_center[1]-car_small_rot.get_rect()[3]/2.)
        screen.blit(car_small_rot, pos)
        blits_bg.append(pos+tuple(car_small_rot.get_rect()[2:]))
    pygame.display.update()
    global pg_background
    for blit_bg in blits_bg:
       screen.blit(pg_background, blit_bg[:2], blit_bg)
    print "-------------------------------------------"
    
    
def visualizer():
    rospy.init_node('visualizer', anonymous=True)
    rospy.Subscriber('world_state', String, update_state)
    rospy.spin()

if __name__ == '__main__':
    file_location = "RoadModule/HighwaySML"
    road_module = RoadModule.RoadModule(file_location)
    
    
    desired_window_width = float(800)
    desired_window_height = float(600)
    desired_pixel_per_meter = float(5)
    ground_projection = True
    projector_area = [3.360, 4.490, 2.920, 2.970]
    bg_surface = None
    vehicles_dict = dict()
    areas_to_blit = []
    # load image meta data
    meta_data_filename = file_location + '.meta'
    with open(meta_data_filename, 'r') as f:
        meta_data_string = f.read()
    
    tokens = meta_data_string.split(';')
    for token in tokens:
        property_tokens = token.split('=')
        if len(property_tokens) != 2:
            print "Error parsing meta data file!"
            continue
        attribute_token = property_tokens[0]
        value_token = property_tokens[1]
        
        if attribute_token == "image_width":
            loaded_image_width = float(value_token)
        elif attribute_token == "image_height":
            loaded_image_height = float(value_token)
        elif attribute_token == "pixel_per_meter":
            loaded_image_pixel_per_meter = float(value_token)
        else:
           print "Error parsing meta data file!"
           continue
    loaded_image_center_x = loaded_image_width/2.
    loaded_image_center_y = loaded_image_height/2.
    
    # load image
    pygame.init()
    image_file = file_location+'.bmp'
    global pg_background
    pg_background = pygame.image.load(image_file)
    
    if ground_projection:
        top_left_x = loaded_image_center_x - projector_area[0]*32.*loaded_image_pixel_per_meter
        top_left_y = loaded_image_center_y - projector_area[2]*32.*loaded_image_pixel_per_meter
        bot_right_x = loaded_image_center_x + projector_area[1]*32.*loaded_image_pixel_per_meter
        bot_right_y = loaded_image_center_y + projector_area[3]*32.*loaded_image_pixel_per_meter
       
        top_left_x = int(round(top_left_x))
        top_left_y = int(round(top_left_y))
        bot_right_x = int(round(bot_right_x))
        bot_right_y = int(round(bot_right_y))
       
        background_array = pygame.PixelArray(pg_background)
        cropped_image_array = background_array[top_left_x:bot_right_x, top_left_y:bot_right_y]
       
        pg_background = cropped_image_array.make_surface()
        pg_background = pygame.transform.smoothscale(pg_background, (int(desired_window_width), int(desired_window_height)))
        #pg_background_array = pygame.surfarray.array3d(pg_background)
       
        #image_pixel_per_meter = desired_window_width/((projector_area[0]+projector_area[1])*32.)
        #image_pixel_per_meter = desired_window_width/((projector_area[3]+projector_area[2])*32.)
        
        image_center_x = desired_window_width*(projector_area[0]/(projector_area[0]+projector_area[1]))
        image_center_y = desired_window_height*(projector_area[2]/(projector_area[2]+projector_area[3]))
        global image_center
        image_center = (image_center_x, image_center_y)
    
    #pg_background_pixel_array = pygame.PixelArray(pg_background)
    #areas_to_blit.append([0,0,int(desired_window_width), int(desired_window_height)])
    image_size = (int(desired_window_width), int(desired_window_height))
    
    if ground_projection:
        x = 0
        y = 0
        os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" % (x,y)
        global screen
        screen = pygame.display.set_mode(image_size)
    
    #screen.blit(pg_background_array.make_surface(), (0,0))
    screen.blit(pg_background, (0,0))
    pygame.display.flip()
    visualizer()

