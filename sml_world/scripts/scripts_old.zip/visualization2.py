#!/usr/bin/env python
# license removed for brevity
"""
Visualization mode of the SML-World.

Created on Feb 24, 2016

@author: U{David Spulak<spulak@kth.se>}
@organization: KTH
"""
import os
import sys

import rospy
from std_msgs.msg import String

import pygame

sys.path.append('RoadModule')
import RoadModule
import VisualisationModule

if __name__ == '__main__':
    file_location = "RoadModule/HighwaySML"
    road_module = RoadModule.RoadModule(file_location)
    
    visualization = VisualisationModule.VisualisationModule()